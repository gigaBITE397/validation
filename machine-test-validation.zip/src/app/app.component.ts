import { Component ,OnInit } from '@angular/core';
import {FormGroup, FormControl,  FormGroupDirective, NgForm,Validators,FormBuilder,ControlContainer} from '@angular/forms';
import {ErrorStateMatcher} from '@angular/material/core';

/** Error when invalid control is dirty, touched, or submitted. */
export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{

  //Error generator from Angular Material
  matcher = new MyErrorStateMatcher();

  addForm: FormGroup;

  //Array of some input type
  arrayType : any = [
  	{
  		type : "text"
  	},
  	{
  		type : "number"
  	},
  	{
  		type : "tel"
  	},
  	{
  		type : "email"
  	},
    {
      type : "password"
    },
  	{
  		type : "date"
  	},
  	{
  		type : "week"
  	},
    {
      type : "time"
    },
    {
      type : "url"
    }
  ];

  constructor(private formBuilder: FormBuilder) {
    this.addForm = new FormGroup({});

    //Assigning FormControls Dynamically
    for(let formModule of this.arrayType){

      if(formModule.type == 'email' ){
        this.addForm.addControl(formModule.type,new FormControl('',[Validators.required,Validators.email]))
      }
      else
        if(formModule.type == 'tel' ){
          this.addForm.addControl(formModule.type,new FormControl('',[Validators.required,Validators.minLength(3),Validators.maxLength(10),Validators.pattern("[0-9]*")]))
      }
      else
        if(formModule.type == 'number' ){
          this.addForm.addControl(formModule.type,new FormControl('',[Validators.required,Validators.pattern("[0-9]*")]))
      }
      else
        if(formModule.type == 'password' ){
          this.addForm.addControl(formModule.type,new FormControl('',[Validators.required,Validators.minLength(3)]))
      }
      else{
        this.addForm.addControl(formModule.type,new FormControl('',Validators.required))
      }
    }
    
    //To check form Controls are assigned or not
    //console.log(this.addForm);
  }

  ngOnInit() {  }

  // convenience getter for easy access to form fields
  get f() { return this.addForm.controls; }

  submitData(){
    console.log(this.addForm.value);
  }

}